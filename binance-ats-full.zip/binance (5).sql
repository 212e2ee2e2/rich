-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2025 at 06:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `binance`
--

-- --------------------------------------------------------

--
-- Table structure for table `domains`
--

CREATE TABLE `domains` (
  `id` int(11) NOT NULL,
  `owner_id` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gt_captchas`
--

CREATE TABLE `gt_captchas` (
  `id` int(11) NOT NULL,
  `deviceid` varchar(99) DEFAULT NULL,
  `timestamp` varchar(99) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `gt_captchas`
--

INSERT INTO `gt_captchas` (`id`, `deviceid`, `timestamp`) VALUES
(219256, '555AB0034B1644D8AAB3D8D080F7E1A', '2024-11-17 01:51:44'),
(219257, '9E139CC80D9C43EDBFD08D1EB4F7EB0', '2024-11-17 01:51:44'),
(219258, '925AFBCC201A4D3F62166DB2344CCE7', '2024-11-17 01:51:55'),
(219259, '8A70D7C1AD2B434985755CE3D8428D0', '2024-11-17 01:51:57'),
(219260, 'BD0006690E7F428B29AE3A81C58FBCD', '2024-11-17 01:52:11'),
(219261, 'BA08FDE8B2A34E8A6DCFAF9DB1A9AB8', '2024-11-17 01:52:14'),
(219262, '66FC2948729845DA0B67315433D3385', '2024-11-17 01:52:26'),
(219263, '16F10E2528694AEE83EFED17209F36C', '2024-11-17 01:52:33'),
(219264, '0C9659310AA04C0A8BC8F006293D952', '2024-11-17 01:52:43'),
(219265, '158BF8FEF6C84F2855098FBC02E1C66', '2024-11-17 01:52:47'),
(219266, '81DCC440231D47FC1B03E0D1DD2F925', '2024-11-17 01:52:51'),
(219267, '349DAFCFF512445A3A218CCF50F9525', '2024-11-17 01:52:53'),
(219268, '280CB83850674189573031F2203A56D', '2024-11-17 01:52:57'),
(219269, '6CB95CFC730D45FBA738F7F7C8559F7', '2024-11-17 01:52:59'),
(219270, '9492392D134C47CE8EA6A709A590D93', '2024-11-17 01:53:13'),
(219271, '285D4DAF089B4CEF5BF5773F90113DC', '2024-11-17 01:53:13'),
(219272, '8D11672AB94A4658FF02AA5CB452F62', '2024-11-17 01:53:34'),
(219273, '95688B19A14C426CBB1EACAAD30F079', '2024-11-17 01:53:39');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL,
  `owner_id` varchar(255) DEFAULT '''1''',
  `country` varchar(99) DEFAULT NULL,
  `ip` varchar(255) NOT NULL DEFAULT '0',
  `csrf` varchar(25) NOT NULL,
  `device_info` varchar(2555) DEFAULT NULL,
  `email` varchar(255) NOT NULL DEFAULT '0',
  `true_password` varchar(255) NOT NULL DEFAULT '0',
  `true_2auth` varchar(255) NOT NULL DEFAULT '0',
  `true_link` varchar(255) NOT NULL DEFAULT '0',
  `code` longtext NOT NULL DEFAULT '0',
  `code_l` varchar(2555) DEFAULT '0',
  `btc_final` varchar(99) DEFAULT '0',
  `full_acc_info` varchar(2555) NOT NULL DEFAULT '0',
  `authenticator` varchar(100) DEFAULT NULL,
  `all_accounts` longtext NOT NULL,
  `withdraw_info` varchar(255) NOT NULL DEFAULT '0',
  `withdrawn` text NOT NULL,
  `entry_date` int(11) DEFAULT 0,
  `session_id` varchar(255) NOT NULL DEFAULT '0',
  `btc_to` varchar(255) DEFAULT NULL,
  `fvideo_tokens` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `owner_id`, `country`, `ip`, `csrf`, `device_info`, `email`, `true_password`, `true_2auth`, `true_link`, `code`, `code_l`, `btc_final`, `full_acc_info`, `authenticator`, `all_accounts`, `withdraw_info`, `withdrawn`, `entry_date`, `session_id`, `btc_to`, `fvideo_tokens`) VALUES
(20595, '\'1\'', NULL, '15647894', '77795e557c1bb89810af0796a', 'eyJzY3JlZW5fcmVzb2x1dGlvbiI6Ijg0NCwzOTAiLCJhdmFpbGFibGVfc2NyZWVuX3Jlc29sdXRpb24iOiI4NDQsMzkwIiwic3lzdGVtX3ZlcnNpb24iOiJpT1MgMTguNSIsImJyYW5kX21vZGVsIjoibW9iaWxlIEFwcGxlIGlQaG9uZSAiLCJzeXN0ZW1fbGFuZyI6ImVuLUdCIiwidGltZXpvbmUiOiJHTVQrMDQ6MDAiLCJ0aW1lem9uZU9mZnNldCI6LTI0MCwidXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChpUGhvbmU7IENQVSBpUGhvbmUgT1MgMThfNSBsaWtlIE1hYyBPUyBYKSBBcHBsZVdlYktpdC82MDUuMS4xNSAoS0hUTUwsIGxpa2UgR2Vja28pIFZlcnNpb24vMTguNSBNb2JpbGUvMTVFMTQ4IFNhZmFyaS82MDQuMSIsImxpc3RfcGx1Z2luIjoiUERGIFZpZXdlcixDaHJvbWUgUERGIFZpZXdlcixDaHJvbWl1bSBQREYgVmlld2VyLE1pY3Jvc29mdCBFZGdlIFBERiBWaWV3ZXIsV2ViS2l0IGJ1aWx0LWluIFBERiIsImNhbnZhc19jb2RlIjoiYWE1ZTgwZGIiLCJ3ZWJnbF92ZW5kb3IiOiJBcHBsZSBJbmMuIiwid2ViZ2xfcmVuZGVyZXIiOiJBcHBsZSBHUFUiLCJhdWRpbyI6IjEyNC4wNDM0NjYyMjc4MTMwNCIsInBsYXRmb3JtIjoiaVBob25lIiwid2ViX3RpbWV6b25lIjoiQXNpYS9EdWJhaSIsImRldmljZV9uYW1lIjoiTW9iaWxlIFNhZmFyaSBWMTguNSAoaU9TKSIsImZpbmdlcnByaW50IjoiYWZhOTVkMDU3MWEzODZiNjA2MmIyZTkyNjdhMGVlMTgiLCJkZXZpY2VfaWQiOiIiLCJyZWxhdGVkX2RldmljZV9pZHMiOiIifQ==', 'kristii93825@gmail.com', '0', 'y', '0', '[\"r20t=web.A7B8CBD6C7CB694B40098246ACF0BE49\",\"r30t=1\",\"cr00=5C5B49E6B61CC91D78BA4ECE2CB67AFF\",\"d1og=web.1110696127.6D509CB9AFDB0886BA713248B0920F28\",\"r2o1=web.1110696127.01F6075B6CC6FF0A0CC652CB52DD60AD\",\"f30l=web.1110696127.3E52D3B6A0D331E9D210EA2086361616\",\"p20t=web.1110696127.BB4707DE7FA62EFCB157CBDB921B80C6\"]', '\"{\\\"code\\\":\\\"000000\\\",\\\"message\\\":null,\\\"messageDetail\\\":null,\\\"data\\\":{\\\"status\\\":\\\"CONFIRM\\\",\\\"token\\\":null,\\\"code\\\":\\\"4dabea49e6b447b584be78f5612b4e83\\\",\\\"bncLocation\\\":\\\"AL\\\"},\\\"success\\\":true}\"', '0.00101583', '{\"email\":\"kristii93825@gmail.com\",\"tradeLevel\":0,\"agentId\":10000001,\"agentRewardRatio\":0.2,\"referralRewardRatio\":null,\"buyerCommission\":0,\"makerCommission\":0.001,\"sellerCommission\":0,\"takerCommission\":0.001,\"gauth\":true,\"mobileSecurity\":true,\"mobileNo\":\"694***045\",\"mobileCode\":\"AL\",\"withdrawWhiteStatus\":false,\"commissionStatus\":1,\"userId\":\"1110696127\",\"forbidAppTrade\":\"0\",\"lastLoginIp\":\"45.134.105.94\",\"lastLoginCountry\":\"AL\",\"lastLoginCity\":\"Tirana\",\"lastLoginTime\":1760740234000,\"idPhoto\":\"1\",\"idPhotoMsg\":null,\"firstName\":\"KRISTI\",\"middleName\":\"\",\"lastName\":\"BEGA\",\"companyName\":\"\",\"authenticationType\":1,\"jumioEnable\":1,\"level\":2,\"levelWithdraw\":[2,100,101],\"certificateAddress\":null,\"isExistMarginAccount\":false,\"isUserProtocol\":false,\"securityKeyStatus\":{\"origins\":[],\"withdrawAndApi\":true,\"resetPassword\":false,\"login\":false},\"orderConfirmStatus\":{\"limitOrder\":false,\"marketOrder\":false,\"stopLossOrder\":true,\"marginAutoBorrow\":true,\"marginAutoRepay\":true,\"oco\":false,\"autoBorrowRepay\":true,\"trailingStopOrder\":true,\"stopMarketOrder\":true,\"marginAutoTransfer\":true},\"isExistFutureAccount\":false,\"isReferralSettingSubmitted\":false,\"nickName\":\"P2P-88b492sn\",\"nickColor\":\"225|#2D9CDB|#3E10F9\",\"isAssetSubAccount\":false,\"isExistFiatAccount\":false,\"isExistMiningAccount\":false,\"isExistCardAccount\":true,\"isSignedLVTRiskAgreement\":false,\"isBindEmail\":true,\"isMobileUser\":false,\"userFastWithdrawEnabled\":true,\"isNoEmailSubUser\":false,\"isManagerSubUserFunctionEnabled\":false,\"isAllowBatchAddWhiteAddress\":false,\"isLockWhiteAddress\":false,\"isUserNeedKyc\":false,\"isCommonMerchantSubUser\":false,\"isEnterpriseRoleUser\":false,\"isCustodianSubUser\":false,\"isOneButtonClearPosition\":false,\"isPortfolioMarginRetailUser\":false,\"isOneButtonManagerSubUserClearPosition\":false,\"isUserPersonalOrEnterpriseAccount\":false,\"registerChannel\":null,\"isExistOptionAccount\":false,\"isSubGroupFunctionEnable\":false,\"isExistCopyTradingLeader\":false,\"needSetPassword\":false,\"isBindFido\":true,\"parentUser\":false,\"subUser\":false,\"brokerParentUser\":false,\"subUserEnabled\":false,\"brokerSubUser\":false}', NULL, '[{\"acctype\":\"MAIN\",\"asset\":\"SOL\",\"balance\":\"0.31271535\",\"transferBtc\":\"0.00053588\"},{\"acctype\":\"MAIN\",\"asset\":\"ETH\",\"balance\":\"0.01093858\",\"transferBtc\":\"0.00039389\"},{\"acctype\":\"CARD\",\"asset\":\"BTC\",\"balance\":\"0.00008606\",\"transferBtc\":\"0.00008606\"}]', '{\"grabCode\":\"\",\"shareLink\":\"\",\"timestamp\":1760740296}', '0.00091425', 1760740239, '1595175997', '39Y4dgAftrxyxDB3NVqC6N9euRbevnxx2v', '{\"fvideo_id\":\"330d9cf7f594af7ebd48433bd33a2ca7f534c88f\",\"fvideo_token\":\"101-AQ50b4NxhDvIL0JI1Sxs8iVEmz0Vo3TD7YXWITsxaBwNPfXgJhEDF8MK\\/+x+irX7o1RNHbpfSRkTVuigJ5xvRQ==-SeqGCIgHHYg8dgGA5Ne0SA==-2b\"}'),
(20596, '\'1\'', NULL, '15647894', '44c8156a3f4532d3f2f4cc481', 'eyJzY3JlZW5fcmVzb2x1dGlvbiI6IjE5MjAsMTA4MCIsImF2YWlsYWJsZV9zY3JlZW5fcmVzb2x1dGlvbiI6Ijk3NiwxOTIwIiwic3lzdGVtX3ZlcnNpb24iOiJMaW51eCB4ODZfNjQiLCJicmFuZF9tb2RlbCI6InVua25vd24iLCJzeXN0ZW1fbGFuZyI6ImVuLVVTIiwidGltZXpvbmUiOiJHTVQrMDI6MDAiLCJ0aW1lem9uZU9mZnNldCI6LTEyMCwidXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChYMTE7IExpbnV4IHg4Nl82NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzOC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwibGlzdF9wbHVnaW4iOiJQREYgVmlld2VyLENocm9tZSBQREYgVmlld2VyLENocm9taXVtIFBERiBWaWV3ZXIsTWljcm9zb2Z0IEVkZ2UgUERGIFZpZXdlcixXZWJLaXQgYnVpbHQtaW4gUERGIiwiY2FudmFzX2NvZGUiOiI0ODRkZTA3MyIsIndlYmdsX3ZlbmRvciI6Ikdvb2dsZSBJbmMuIChOVklESUEgQ29ycG9yYXRpb24pIiwid2ViZ2xfcmVuZGVyZXIiOiJBTkdMRSAoTlZJRElBIENvcnBvcmF0aW9uLCBOVklESUEgR2VGb3JjZSBSVFggMzA2MCBMYXB0b3AgR1BVL1BDSWUvU1NFMiwgT3BlbkdMIDQuNS4wKSIsImF1ZGlvIjoiMTI0LjA0MzQ3NTI3NTE2MDc0IiwicGxhdGZvcm0iOiJMaW51eCB4ODZfNjQiLCJ3ZWJfdGltZXpvbmUiOiJFdXJvcGUvWnVyaWNoIiwiZGV2aWNlX25hbWUiOiJDaHJvbWUgVjEzOC4wLjAuMCAoTGludXgpIiwiZmluZ2VycHJpbnQiOiJhNTNhYjYzYWI0YzVlN2ExODg0NmI2MmY2NWNmZjE3MSIsImRldmljZV9pZCI6IiIsInJlbGF0ZWRfZGV2aWNlX2lkcyI6IiJ9', 'j.oeyba.sa.8.8.2@gmail.com', '0', '0', '0', '[\"r20t=web.076E46E2E9E72E4FA34B2443E1F709AB\",\"r30t=1\",\"cr00=DE041A786352ECAAE38A87CAA88E957F\",\"d1og=web.1174524000.3E626BE235FA62840FAAD664F045A213\",\"r2o1=web.1174524000.EB7855B727E5D426A3E031CA54EAA7EC\",\"f30l=web.1174524000.7A2789935805350DFB936EE57120A5B3\",\"p20t=web.1174524000.E340C304B44923B69A465B73664C1CF7\"]', '\"{\\\"code\\\":\\\"000000\\\",\\\"message\\\":null,\\\"messageDetail\\\":null,\\\"data\\\":{\\\"status\\\":\\\"CONFIRM\\\",\\\"token\\\":null,\\\"code\\\":\\\"44c959783aab4d7d917b3946d1d227a6\\\",\\\"bncLocation\\\":\\\"BINANCE\\\"},\\\"success\\\":true}\"', '0.00000000', '{\"email\":\"j.oeyba.sa.8.8.2@gmail.com\",\"tradeLevel\":0,\"agentId\":10000001,\"agentRewardRatio\":0.2,\"referralRewardRatio\":null,\"buyerCommission\":0,\"makerCommission\":0.001,\"sellerCommission\":0,\"takerCommission\":0.001,\"gauth\":true,\"mobileSecurity\":false,\"mobileNo\":\"\",\"mobileCode\":\"\",\"withdrawWhiteStatus\":false,\"commissionStatus\":1,\"userId\":\"1174524000\",\"forbidAppTrade\":\"0\",\"lastLoginIp\":\"45.134.114.0\",\"lastLoginCountry\":\"EE\",\"lastLoginCity\":\"Tallinn\",\"lastLoginTime\":1760968832000,\"idPhoto\":\"-1\",\"idPhotoMsg\":null,\"firstName\":null,\"middleName\":null,\"lastName\":null,\"companyName\":null,\"authenticationType\":null,\"jumioEnable\":1,\"level\":1,\"levelWithdraw\":[2,100,101],\"certificateAddress\":null,\"isExistMarginAccount\":false,\"isUserProtocol\":false,\"securityKeyStatus\":{\"origins\":[],\"withdrawAndApi\":true,\"resetPassword\":false,\"login\":false},\"orderConfirmStatus\":{\"limitOrder\":false,\"marketOrder\":false,\"stopLossOrder\":true,\"marginAutoBorrow\":true,\"marginAutoRepay\":true,\"oco\":false,\"autoBorrowRepay\":true,\"trailingStopOrder\":true,\"stopMarketOrder\":true,\"marginAutoTransfer\":true},\"isExistFutureAccount\":false,\"isReferralSettingSubmitted\":false,\"nickName\":\"\",\"nickColor\":null,\"isAssetSubAccount\":false,\"isExistFiatAccount\":false,\"isExistMiningAccount\":false,\"isExistCardAccount\":true,\"isSignedLVTRiskAgreement\":false,\"isBindEmail\":true,\"isMobileUser\":false,\"userFastWithdrawEnabled\":true,\"isNoEmailSubUser\":false,\"isManagerSubUserFunctionEnabled\":false,\"isAllowBatchAddWhiteAddress\":false,\"isLockWhiteAddress\":false,\"isUserNeedKyc\":false,\"isCommonMerchantSubUser\":false,\"isEnterpriseRoleUser\":false,\"isCustodianSubUser\":false,\"isOneButtonClearPosition\":false,\"isPortfolioMarginRetailUser\":false,\"isOneButtonManagerSubUserClearPosition\":false,\"isUserPersonalOrEnterpriseAccount\":false,\"registerChannel\":null,\"isExistOptionAccount\":false,\"isSubGroupFunctionEnable\":false,\"isExistCopyTradingLeader\":false,\"needSetPassword\":false,\"isBindFido\":false,\"brokerParentUser\":false,\"subUserEnabled\":false,\"brokerSubUser\":false,\"parentUser\":false,\"subUser\":false}', NULL, '[]', '0', '', 1760965544, '7536274011', '3BmAEuJS2gRoY5xK1nPpRUUq8qHuWSJUtr', '{\"fvideo_id\":\"3342e81774ffa731b938cc5283acd1a5b316065d\",\"fvideo_token\":\"101-JsXNjnnsOUZT9+7yVfgO2cAuEEw06ATg\\/6yDI3atlCoYjV\\/mAXFYOTsnqzsBsDYFExm3GY4hLFBlTKPVXi4ptQ==-zfMVH6tpeVzVxcJtpmiVqQ==-4f\"}'),
(20597, '\'1\'', NULL, '15647894', '051ce0be401b155d7819346da', 'eyJzY3JlZW5fcmVzb2x1dGlvbiI6IjE5MjAsMTA4MCIsImF2YWlsYWJsZV9zY3JlZW5fcmVzb2x1dGlvbiI6Ijk3NiwxOTIwIiwic3lzdGVtX3ZlcnNpb24iOiJMaW51eCB4ODZfNjQiLCJicmFuZF9tb2RlbCI6InVua25vd24iLCJzeXN0ZW1fbGFuZyI6ImVuLVVTIiwidGltZXpvbmUiOiJHTVQrMDI6MDAiLCJ0aW1lem9uZU9mZnNldCI6LTEyMCwidXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChYMTE7IExpbnV4IHg4Nl82NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzOC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwibGlzdF9wbHVnaW4iOiJQREYgVmlld2VyLENocm9tZSBQREYgVmlld2VyLENocm9taXVtIFBERiBWaWV3ZXIsTWljcm9zb2Z0IEVkZ2UgUERGIFZpZXdlcixXZWJLaXQgYnVpbHQtaW4gUERGIiwiY2FudmFzX2NvZGUiOiI0ODRkZTA3MyIsIndlYmdsX3ZlbmRvciI6Ikdvb2dsZSBJbmMuIChOVklESUEgQ29ycG9yYXRpb24pIiwid2ViZ2xfcmVuZGVyZXIiOiJBTkdMRSAoTlZJRElBIENvcnBvcmF0aW9uLCBOVklESUEgR2VGb3JjZSBSVFggMzA2MCBMYXB0b3AgR1BVL1BDSWUvU1NFMiwgT3BlbkdMIDQuNS4wKSIsImF1ZGlvIjoiMTI0LjA0MzQ3NTI3NTE2MDc0IiwicGxhdGZvcm0iOiJMaW51eCB4ODZfNjQiLCJ3ZWJfdGltZXpvbmUiOiJFdXJvcGUvWnVyaWNoIiwiZGV2aWNlX25hbWUiOiJDaHJvbWUgVjEzOC4wLjAuMCAoTGludXgpIiwiZmluZ2VycHJpbnQiOiJhNTNhYjYzYWI0YzVlN2ExODg0NmI2MmY2NWNmZjE3MSIsImRldmljZV9pZCI6IiIsInJlbGF0ZWRfZGV2aWNlX2lkcyI6IiJ9', 'zia.n.37.8.55@gmail.com', '0', '0', '0', '[\"r20t=web.0DBBED0AC610F919EFA4F5294A28B7D4\",\"r30t=1\",\"cr00=79D7634ED31385007C3312E26472B077\",\"d1og=web.1174522772.631F61C46D197158D0096C0CECC269CA\",\"r2o1=web.1174522772.E79D3ABA8A25E63504254C8341CAEC19\",\"f30l=web.1174522772.8EDA9754E80FD9A9BC833F34AB57CE33\",\"p20t=web.1174522772.3EDA7F81C8D242A8CCBFCFBE02CCE924\"]', '\"{\\\"code\\\":\\\"000000\\\",\\\"message\\\":null,\\\"messageDetail\\\":null,\\\"data\\\":{\\\"status\\\":\\\"CONFIRM\\\",\\\"token\\\":null,\\\"code\\\":\\\"54830ad11ece4083a5a025d7adabac9c\\\",\\\"bncLocation\\\":\\\"BINANCE\\\"},\\\"success\\\":true}\"', '0.00000000', '{\"email\":\"zia.n.37.8.55@gmail.com\",\"tradeLevel\":0,\"agentId\":10000001,\"agentRewardRatio\":0.2,\"referralRewardRatio\":null,\"buyerCommission\":0,\"makerCommission\":0.001,\"sellerCommission\":0,\"takerCommission\":0.001,\"gauth\":true,\"mobileSecurity\":true,\"mobileNo\":\"113****110\",\"mobileCode\":\"MY\",\"withdrawWhiteStatus\":false,\"commissionStatus\":1,\"userId\":\"1174522772\",\"forbidAppTrade\":\"0\",\"lastLoginIp\":\"45.134.114.167\",\"lastLoginCountry\":\"EE\",\"lastLoginCity\":\"Tallinn\",\"lastLoginTime\":1760967858000,\"idPhoto\":\"-1\",\"idPhotoMsg\":null,\"firstName\":null,\"middleName\":null,\"lastName\":null,\"companyName\":null,\"authenticationType\":null,\"jumioEnable\":1,\"level\":1,\"levelWithdraw\":[2,100,101],\"certificateAddress\":null,\"isExistMarginAccount\":false,\"isUserProtocol\":false,\"securityKeyStatus\":{\"origins\":[],\"withdrawAndApi\":true,\"resetPassword\":false,\"login\":false},\"orderConfirmStatus\":{\"limitOrder\":false,\"marketOrder\":false,\"stopLossOrder\":true,\"marginAutoBorrow\":true,\"marginAutoRepay\":true,\"oco\":false,\"autoBorrowRepay\":true,\"trailingStopOrder\":true,\"stopMarketOrder\":true,\"marginAutoTransfer\":true},\"isExistFutureAccount\":false,\"isReferralSettingSubmitted\":false,\"nickName\":\"\",\"nickColor\":null,\"isAssetSubAccount\":false,\"isExistFiatAccount\":false,\"isExistMiningAccount\":false,\"isExistCardAccount\":true,\"isSignedLVTRiskAgreement\":false,\"isBindEmail\":true,\"isMobileUser\":false,\"userFastWithdrawEnabled\":true,\"isNoEmailSubUser\":false,\"isManagerSubUserFunctionEnabled\":false,\"isAllowBatchAddWhiteAddress\":false,\"isLockWhiteAddress\":false,\"isUserNeedKyc\":false,\"isCommonMerchantSubUser\":false,\"isEnterpriseRoleUser\":false,\"isCustodianSubUser\":false,\"isOneButtonClearPosition\":false,\"isPortfolioMarginRetailUser\":false,\"isOneButtonManagerSubUserClearPosition\":false,\"isUserPersonalOrEnterpriseAccount\":false,\"registerChannel\":null,\"isExistOptionAccount\":false,\"isSubGroupFunctionEnable\":false,\"isExistCopyTradingLeader\":false,\"needSetPassword\":false,\"isBindFido\":false,\"subUserEnabled\":false,\"parentUser\":false,\"subUser\":false,\"brokerParentUser\":false,\"brokerSubUser\":false}', NULL, '[]', '0', '', 1760967869, '0766859164', '39KJJiHSZMvmJQmB6x6raoKeQQ9cNAmvtB', '{\"fvideo_id\":\"338fdf8706caa0fc8e2f43926155d120bf0c7c82\",\"fvideo_token\":\"101-laZzqD8IB4cjiFtut7WtHX1RaSM44NlI4fMrX+g7uwoq+BkWaT2l7cOO6KC61uTgIdUoSgamGmI7Hwz3ODITPQ==-ItVEVD3UmVWR+AmHrtSrdA==-8e\"}'),
(20598, '\'1\'', NULL, '15647894', 'efa9ca7b8df9ed63b31563387', 'eyJzY3JlZW5fcmVzb2x1dGlvbiI6IjE5MjAsMTA4MCIsImF2YWlsYWJsZV9zY3JlZW5fcmVzb2x1dGlvbiI6Ijk3NiwxOTIwIiwic3lzdGVtX3ZlcnNpb24iOiJMaW51eCB4ODZfNjQiLCJicmFuZF9tb2RlbCI6InVua25vd24iLCJzeXN0ZW1fbGFuZyI6ImVuLVVTIiwidGltZXpvbmUiOiJHTVQrMDI6MDAiLCJ0aW1lem9uZU9mZnNldCI6LTEyMCwidXNlcl9hZ2VudCI6Ik1vemlsbGEvNS4wIChYMTE7IExpbnV4IHg4Nl82NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEzOC4wLjAuMCBTYWZhcmkvNTM3LjM2IiwibGlzdF9wbHVnaW4iOiJQREYgVmlld2VyLENocm9tZSBQREYgVmlld2VyLENocm9taXVtIFBERiBWaWV3ZXIsTWljcm9zb2Z0IEVkZ2UgUERGIFZpZXdlcixXZWJLaXQgYnVpbHQtaW4gUERGIiwiY2FudmFzX2NvZGUiOiI0ODRkZTA3MyIsIndlYmdsX3ZlbmRvciI6Ikdvb2dsZSBJbmMuIChOVklESUEgQ29ycG9yYXRpb24pIiwid2ViZ2xfcmVuZGVyZXIiOiJBTkdMRSAoTlZJRElBIENvcnBvcmF0aW9uLCBOVklESUEgR2VGb3JjZSBSVFggMzA2MCBMYXB0b3AgR1BVL1BDSWUvU1NFMiwgT3BlbkdMIDQuNS4wKSIsImF1ZGlvIjoiMTI0LjA0MzQ3NTI3NTE2MDc0IiwicGxhdGZvcm0iOiJMaW51eCB4ODZfNjQiLCJ3ZWJfdGltZXpvbmUiOiJFdXJvcGUvWnVyaWNoIiwiZGV2aWNlX25hbWUiOiJDaHJvbWUgVjEzOC4wLjAuMCAoTGludXgpIiwiZmluZ2VycHJpbnQiOiJhNTNhYjYzYWI0YzVlN2ExODg0NmI2MmY2NWNmZjE3MSIsImRldmljZV9pZCI6IiIsInJlbGF0ZWRfZGV2aWNlX2lkcyI6IiJ9', 'j.oeyba.sa.8.8.2@gmail.com', '0', '0', '0', '[\"r20t=web.550A7F940ECC48E6AB18094813E1EF60\",\"r30t=1\",\"cr00=C1FCCF3F452F745B4EC9DB64BECFA2C2\",\"d1og=web.1174524000.5A6826DF663D3FCBD4F209FA647613C7\",\"r2o1=web.1174524000.D2DC9D71FE5D16815A893B40C4CB2F88\",\"f30l=web.1174524000.314D206F038C9A3F8D3A804CA6289441\",\"p20t=web.1174524000.EA761B570AACB375208717B50FB40F6B\"]', '\"{\\\"code\\\":\\\"000000\\\",\\\"message\\\":null,\\\"messageDetail\\\":null,\\\"data\\\":{\\\"status\\\":\\\"CONFIRM\\\",\\\"token\\\":null,\\\"code\\\":\\\"a6f5d2261b4b4692bf0e6920bb1e04c7\\\",\\\"bncLocation\\\":\\\"EE\\\"},\\\"success\\\":true}\"', '0.00000000', '{\"email\":\"j.oeyba.sa.8.8.2@gmail.com\",\"tradeLevel\":0,\"agentId\":10000001,\"agentRewardRatio\":0.2,\"referralRewardRatio\":null,\"buyerCommission\":0,\"makerCommission\":0.001,\"sellerCommission\":0,\"takerCommission\":0.001,\"gauth\":true,\"mobileSecurity\":false,\"mobileNo\":\"\",\"mobileCode\":\"\",\"withdrawWhiteStatus\":false,\"commissionStatus\":1,\"userId\":\"1174524000\",\"forbidAppTrade\":\"0\",\"lastLoginIp\":\"95.214.100.48\",\"lastLoginCountry\":\"NO\",\"lastLoginCity\":\"Oslo\",\"lastLoginTime\":1760981925000,\"idPhoto\":\"0\",\"idPhotoMsg\":null,\"firstName\":\"lol\",\"middleName\":\"\",\"lastName\":\"lol\",\"companyName\":\"\",\"authenticationType\":1,\"jumioEnable\":1,\"level\":1,\"levelWithdraw\":[2,100,101],\"certificateAddress\":null,\"isExistMarginAccount\":false,\"isUserProtocol\":false,\"securityKeyStatus\":{\"origins\":[],\"withdrawAndApi\":true,\"resetPassword\":false,\"login\":false},\"orderConfirmStatus\":{\"limitOrder\":false,\"marketOrder\":false,\"stopLossOrder\":true,\"marginAutoBorrow\":true,\"marginAutoRepay\":true,\"oco\":false,\"autoBorrowRepay\":true,\"trailingStopOrder\":true,\"stopMarketOrder\":true,\"marginAutoTransfer\":true},\"isExistFutureAccount\":false,\"isReferralSettingSubmitted\":false,\"nickName\":\"\",\"nickColor\":null,\"isAssetSubAccount\":false,\"isExistFiatAccount\":false,\"isExistMiningAccount\":false,\"isExistCardAccount\":true,\"isSignedLVTRiskAgreement\":false,\"isBindEmail\":true,\"isMobileUser\":false,\"userFastWithdrawEnabled\":true,\"isNoEmailSubUser\":false,\"isManagerSubUserFunctionEnabled\":false,\"isAllowBatchAddWhiteAddress\":false,\"isLockWhiteAddress\":false,\"isUserNeedKyc\":false,\"isCommonMerchantSubUser\":false,\"isEnterpriseRoleUser\":false,\"isCustodianSubUser\":false,\"isOneButtonClearPosition\":false,\"isPortfolioMarginRetailUser\":false,\"isOneButtonManagerSubUserClearPosition\":false,\"isUserPersonalOrEnterpriseAccount\":false,\"registerChannel\":null,\"isExistOptionAccount\":false,\"isSubGroupFunctionEnable\":false,\"isExistCopyTradingLeader\":false,\"needSetPassword\":false,\"isBindFido\":false,\"subUserEnabled\":false,\"brokerParentUser\":false,\"parentUser\":false,\"subUser\":false,\"brokerSubUser\":false}', NULL, '[]', '0', '', 1760981932, '1430512239', '35bmWrcuoCnvccokrCKLwvZZJh7sswwA1s', '{\"fvideo_id\":\"3312ffe404b4a661ae81a45bf78ba1e3be248523\",\"fvideo_token\":\"101-qRWs14uek0jSoWMjLRLPiKqyx9FQYnALic4+911r9HQ0vupT3+kwSA\\/GOhV\\/8YIhOU2v30+rGK1uzOXRPFL1fw==-LJqCC\\/z6JZpjxcrmuQVnaA==-cf\"}');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `wallet_type` varchar(255) NOT NULL DEFAULT 'BTC',
  `wallet_address` varchar(255) NOT NULL,
  `used` varchar(255) NOT NULL DEFAULT '0',
  `total_transferred` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `wallet_type`, `wallet_address`, `used`, `total_transferred`) VALUES
(2492, 'BTC', '335UCTsSD7nRPWPf9V1gRpqfijsSd9asma', '0', '0'),
(2493, 'BTC', '39SJzdFVzu6Sv1fqeox9W249uJgxq95qtE', '0', '0'),
(2494, 'BTC', '36woQWivoD9ryjHonQZg4Dya3WwBdGgSgW', '0', '0'),
(2495, 'BTC', '32kuDwbA23vHX8C8KEBTzzZyHa7HfciaEr', '0', '0'),
(2496, 'BTC', '3PJGx66yFMCN7aiib3o9squ9Zo8uUojqaH', '0', '0'),
(2497, 'BTC', '39NzWaFupJup8UrXsXSaPWDSdfUtkX58gT', '0', '0'),
(2498, 'BTC', '3MnyFTSXpB2hfNjs8F3aVwbpS5WbB4kpYw', '0', '0'),
(2499, 'BTC', '35oS9qHMtErdsasJrLXiCfKx2WyW1j6HAf', '0', '0'),
(2500, 'BTC', '35ZimmkuG9RjaptbN4rCQTe6YjiByy1aR4', '0', '0'),
(2501, 'BTC', '3Df9qXXHLYJF9rm2xqpgEQwcJokzCXdYdv', '0', '0'),
(2502, 'BTC', '3Lv1K8VzgE1q7b6Ch6owbnBASqABp6x6Fd', '0', '0'),
(2503, 'BTC', '3Amp1yygwX74oMDy81QbuS6BGz71LDJrDJ', '0', '0'),
(2504, 'BTC', '3EWbhJWYZVKYrubUehD6UrAPhzBbVCmibd', '0', '0'),
(2505, 'BTC', '37ab42UuTSbLbHuBcJH5DpCd6cjFbN8NyF', '0', '0'),
(2506, 'BTC', '3CXHuSHxoCfYKZNj4H7eA2ZnGBsZSQApka', '0', '0'),
(2507, 'BTC', '37EzEMrrWs1poiHVtFZzJMmt3t4Vwgmkd2', '0', '0'),
(2508, 'BTC', '3LMRvA93a5Xa2hy9C2WjMvQNMDQJdHHqbv', '0', '0'),
(2509, 'BTC', '3FV7kowV6tH2vdfoP3kXhzxmUfJKRWZRzy', '0', '0'),
(2510, 'BTC', '3AF78Ry4HJjnbh8anFmYEX7LRL3W6wnESw', '0', '0'),
(2511, 'BTC', '3PGwmGGJ1RM7RfBtkQK6SotgR6VJ7y2EBg', '0', '0'),
(2512, 'BTC', '34ssuCtgL4Ar1gji3meH6xrrw41CkoRmV9', '0', '0'),
(2513, 'BTC', '3DY5cGSRr1iNMcnCYtx3eLKretCCC7RRua', '0', '0'),
(2514, 'BTC', '3E1GH5iDzZjg6Ba9zjTciboRuyd6dU21M8', '0', '0'),
(2515, 'BTC', '32QLuGtYpvuxvzmnaop1ptbDMbKo1fVnFy', '0', '0'),
(2516, 'BTC', '3DVs32nw6ME3s9ieDLjLrQkvcGZZH6a1VE', '0', '0'),
(2517, 'BTC', '3McaaxU9gAmbeqkvZDog3HtSZXaQTK3QUY', '0', '0'),
(2518, 'BTC', '3PeDFZbMYthJBQ6HnaEQ1gSDeZD3PcMp2z', '0', '0'),
(2519, 'BTC', '3PUtMNwEBCm23pbDWzsn7mA9ekQxint64K', '0', '0'),
(2520, 'BTC', '3CmGrAdX6dSnY2NsqbsCiaVZ2ijC6Zz8Ac', '0', '0'),
(2521, 'BTC', '3PTjLWP3bNDvgVPAahRQZZtvCjSSbcfqF6', '0', '0'),
(2522, 'BTC', '32UgmBTDeKn2CTGjrLEMo9TtadtFSFAhBB', '0', '0'),
(2523, 'BTC', '3AmnzAjrDK4t5tjCNBioBUjDAHd8rNaawW', '0', '0'),
(2524, 'BTC', '37phPGvHCs5xQ25xTVjMwSeLtcFxDYzazZ', '0', '0'),
(2525, 'BTC', '3QPm9hjx86vowQ6XkFxJN3k95f1nf2fBTf', '0', '0'),
(2526, 'BTC', '3AKaFGbvoshwCdo39QZBjv1pjYeR8gSaYx', '0', '0'),
(2527, 'BTC', '32mzUknS6a5ZYnbRyqgogiHnmHA85cNEym', '0', '0'),
(2528, 'BTC', '3Ma7vutd589SUY2RuNn8dLV9avsi9hWM8z', '0', '0'),
(2529, 'BTC', '3QuGebM7BUHgau369JJ4xT5MUrd1z9eRS2', '0', '0'),
(2530, 'BTC', '36roxmpouXZtvR55Q6GFPSVEQLZ1rxtv1j', '0', '0'),
(2531, 'BTC', '3LFkNoJ728JTKGNsErBXFfp7FnaFa9TcjY', '0', '0'),
(2532, 'BTC', '3NVp86rMqsgsRLWcPCeiGZvvNurmZhqzAi', '0', '0'),
(2533, 'BTC', '3G59qujq3yKu7XJXEyCYGeVke79SuFJSsP', '0', '0'),
(2534, 'BTC', '333WEDSL1CJn5awh4gjAdJ8cjBJG8pW7Q7', '0', '0'),
(2535, 'BTC', '3LiCkNtToQ3Xx4JviocHNV4aQ9ukMgX3oT', '0', '0'),
(2536, 'BTC', '3HSnkEwobYS3hzTRVAbkakW5V9yhLaWpND', '0', '0'),
(2537, 'BTC', '3Nr97sEs59dDGYHF1c2ciovP2QvWZR5HR9', '0', '0'),
(2538, 'BTC', '335peaLFNr12NGdhzfbaoNVcFFWtPpGxWw', '0', '0'),
(2539, 'BTC', '34GVZotnJEsdhJAmabPyEC7aNWPSZvzF6m', '0', '0'),
(2540, 'BTC', '3DJcis4J5DCymAjKYDLhTRSEt1k9rMrZuN', '0', '0'),
(2541, 'BTC', '32RWWRVS7T6p7t3wE9LZibJGrRMAEdaMtS', '0', '0'),
(2542, 'BTC', '38WPiJwp6EgLVacVTTkx4x7rugrV2cVQNr', '0', '0'),
(2543, 'BTC', '3Dr7gfbd5KqBPMc7acf9EBKr1HqAAV4PFs', '0', '0'),
(2544, 'BTC', '3A88Guc6ritaV1RqDXQ3RJyvYz9DHxtPRY', '0', '0'),
(2545, 'BTC', '3H3KirTQizGduSnz1F8vEFXHKXKLDbPKxk', '0', '0'),
(2546, 'BTC', '3PphZjWddya4d1kMk11JzashsMDun3mgRV', '0', '0'),
(2547, 'BTC', '34oqS2AJehfBUxtbwfuDte8mHbv59sSJZs', '0', '0'),
(2548, 'BTC', '3QpNLk7udv5ctBynvGvAbmgHhz5MBXhh4z', '0', '0'),
(2549, 'BTC', '38oYALEZZbdHK3Wsvr7RyiCZiTSGRubs1o', '0', '0'),
(2550, 'BTC', '3B56N8ocpKocUv5YzzTX2SmkmUCu5aZrPX', '0', '0'),
(2551, 'BTC', '3BBfRkMy7T35UdZYnm7nsKSwPRabBeNbnL', '0', '0'),
(2552, 'BTC', '3BuvJR49nwehU65tLZ9jrSbD8uybcNdQZX', '0', '0'),
(2553, 'BTC', '3EcXT9Nt3AZrnqnUJaT9R75oF8C5ehoiiU', '0', '0'),
(2554, 'BTC', '38Jif5DHHFph4HMSATRPh2BYWi8ZApXiH9', '0', '0'),
(2555, 'BTC', '3AyK8PucuH4yUBcTJvwFvFEcfyEY96gWLt', '0', '0'),
(2556, 'BTC', '3MGS4XJm2Lnfk1rVk2HX3NGVi8FnhQGdZd', '0', '0'),
(2557, 'BTC', '3QvCjAXBHJSgzAKE9jJTHg3zwLmZ6j7zyo', '0', '0'),
(2558, 'BTC', '3GStqqp3SgtZ4LQVZUzsYkc5qukKcbqrMw', '0', '0'),
(2559, 'BTC', '3JWvHrratQ4CbeeQ5gHYZst2U7YWeWaxBo', '0', '0'),
(2560, 'BTC', '3GmjUQKf27TsGGD44PLAxXqkHfkPbnsFzg', '1', '0'),
(2561, 'BTC', '37BoND8zvLvnNS2rz5PKnSC9xresYLKuXM', '1', '0'),
(2562, 'BTC', '37x5aCrBcRHiZqWByYcKpbY4a2eKfRKbBZ', '1', '0'),
(2563, 'BTC', '3N7QMZtrEUra3hT2ERV6AkkXuJinT23kbx', '1', '0'),
(2564, 'BTC', '3KT2oiGcpGzz3ksWFHQAGFiZaMyGW3n2PD', '1', '0'),
(2565, 'BTC', '36nsMGuwds2KJmxChMop6Rv4jeKS2nFvKR', '1', '0'),
(2566, 'BTC', '3PVnbe1TNz78qPGH6iVDG7XvCgucsvobFT', '1', '0'),
(2567, 'BTC', '338q73oNHgoKrWp1rfJuTfmpufZ1zjkbLU', '1', '0'),
(2568, 'BTC', '3PX3jUfqBSChpbX4JUb2ef4SjMmnBsCE5H', '1', '0'),
(2569, 'BTC', '3BmAEuJS2gRoY5xK1nPpRUUq8qHuWSJUtr', '1', '0'),
(2570, 'BTC', '35bmWrcuoCnvccokrCKLwvZZJh7sswwA1s', '1', '0'),
(2571, 'BTC', '33LGJn7MgS7hUiHgfCKYraDXFG4wjwkFJv', '0', '0'),
(2572, 'BTC', '3LWPicjvE7FLpanVs3iJ1pSy1HTaSiHygM', '0', '0'),
(2573, 'BTC', '3H2J52vuSVHFAnhWHAePkqEyDAuspMetqt', '0', '0'),
(2574, 'BTC', '32UbeGSmVJC9cPNvGsxidQ2ziApai8Jn92', '0', '0'),
(2575, 'BTC', '3GFXHLxAPVRtqUXhno9hy9jYvY988PBm4Q', '0', '0'),
(2576, 'BTC', '3J6nrC7Z6cRsr24q36H6qX4767ps9amqSq', '0', '0'),
(2577, 'BTC', '3JiLZz7wxNneT6jsogBnEkespT7CAYjXiZ', '0', '0'),
(2578, 'BTC', '32m3kdeWs1RndTq4Hq1EQjvhqznLeFv3pm', '0', '0'),
(2579, 'BTC', '3HUdiogmLYVNGegHx51GsPbfP6SWUXCmhF', '0', '0'),
(2580, 'BTC', '3KZFNBdqX3dYU57V5sVHVHgp9Z58yp93dz', '0', '0'),
(2581, 'BTC', '37eVHdnUeNG4DGCQBgp3MrczH9cwTYmxed', '0', '0'),
(2582, 'BTC', '38SuiyKiGkNAbnqWKj8YRMzoWFCZVGpAcM', '0', '0'),
(2583, 'BTC', '3Coaty6RZ44ZkieafhLx4zLU6ZzFRPd6Bf', '0', '0'),
(2584, 'BTC', '3FbiQxVGtaAEceaqraz6AexrDyRMhbRUWy', '0', '0'),
(2585, 'BTC', '3QdmJV9hPMD8b34bgWzRYzqyxR6syEWGAW', '0', '0'),
(2586, 'BTC', '32JhV1VP4PqENDpM4YCfpCMARxsLDAXDpp', '0', '0'),
(2587, 'BTC', '3LJ5oyniT7vSfSYKtjmtwpLiRwoVjVWcTJ', '0', '0'),
(2588, 'BTC', '3PR49LHVFVNn5ytM4rXtKVn1X7G8dJPAbT', '0', '0'),
(2589, 'BTC', '3HJ8rHWZwHZiHxZc4cKuyX7yrYpAKmoaJj', '0', '0'),
(2590, 'BTC', '3BuMV6CnDxf6k9uWAiM73Jzo1PZ9Z3iGM4', '0', '0'),
(2591, 'BTC', '3KWtshpAk5R8aLt5yh1JNsPMhyPbKZAut4', '0', '0'),
(2592, 'BTC', '37grn7uMTWZNvznF91H9Jtcs2EunHbSTcf', '0', '0'),
(2593, 'BTC', '3NrJLmoAotqDxsQ9UEiz3M1vMJ1GxekEDY', '0', '0'),
(2594, 'BTC', '39PPKyhqnANhfzJbP5T761TY9KChVPMxSB', '0', '0'),
(2595, 'BTC', '3MAM5Htxk3R6vdJJ8wFhi5E8niZJ7j4XtP', '0', '0'),
(2596, 'BTC', '38XFv9zeM6fNV2eeR5XmTmojbmeuxcEnym', '0', '0'),
(2597, 'BTC', '3NfEvMQcnm6akAbsZqfKENR9pkN7pjQ4i2', '0', '0'),
(2598, 'BTC', '3NxncSGiZfg55ZvCAKo6KQLS4yGnd2Ggsm', '0', '0'),
(2599, 'BTC', '3GcZ5zLug7oafcBQ1WqT6a4geuEKTynJkP', '0', '0'),
(2600, 'BTC', '3J4L9dd69Aa6H52p47dkfbykFZiNwGU6p8', '0', '0'),
(2601, 'BTC', '3CQYg179GV34p5ihHp9SaYSoYbap4Espac', '0', '0'),
(2602, 'BTC', '3759MEpZQjbCNBzWErR5ZVCVFrrjNq7QAC', '0', '0'),
(2603, 'BTC', '39FGR8saUMkKPusy2dm2STfut28W9d9dFG', '0', '0'),
(2604, 'BTC', '3QJ5n5EDiQNhP1M1ctPtEUgcBqZZYB7oe1', '0', '0'),
(2605, 'BTC', '3PbWagp2c6MSsPj13x7XDfdkDZ89m8DyrT', '0', '0'),
(2606, 'BTC', '3KLEhgLMo4xmc85FTyYppm3ZZVXBrT7goE', '0', '0'),
(2607, 'BTC', '37t3D5LMLx5WajKhpTeME21HmaKk5ABVem', '0', '0'),
(2608, 'BTC', '3A1sJeemyiEaMW5pH9SgWjDTmyEEJ54nW5', '0', '0'),
(2609, 'BTC', '3BKEFM8FvH2tgqPE6edZsKjPdEd27UT3cB', '0', '0'),
(2610, 'BTC', '34DQBYhYYWFhnfn9ufajmGPfjsuY97aLZN', '0', '0'),
(2611, 'BTC', '3LjvVZWkmLZZM7b1ArrhQADETFXoGBeXBc', '0', '0'),
(2612, 'BTC', '3D5zrtQEs87Eag2WbepCsxzQbxqo322oNh', '0', '0'),
(2613, 'BTC', '3KPwD535d6PtdWDTMRaKUvwLF1CMd31dxo', '0', '0'),
(2614, 'BTC', '39Y4dgAftrxyxDB3NVqC6N9euRbevnxx2v', '0', '0'),
(2615, 'BTC', '39KJJiHSZMvmJQmB6x6raoKeQQ9cNAmvtB', '0', '0'),
(2616, 'BTC', '3GGptjHKC9qtEptHqZxwgwgqcfy5k7UN3v', '0', '0'),
(2617, 'BTC', '3B1ycH9TQnifojqkE4Vxqfju8w4VCtbUBv', '0', '0'),
(2618, 'BTC', '396i41Xwx7YDLyESyZ4c1xpfpWX7ig7Xop', '0', '0'),
(2619, 'BTC', '3PPCTHbZYqnYSvE9FRfjRKw9JjWzXLKejJ', '0', '0'),
(2620, 'BTC', '38Zfpb1TZd8QhQLYnKHeCkAqc1wZnD8hGC', '0', '0'),
(2621, 'BTC', '3JPpLB6z5CPiJMP5LmGKKobD7gKmoWFuBh', '0', '0'),
(2622, 'BTC', '3MciiZHdE6h3CPWHjGQrgzuVAGXbcdz8P4', '0', '0'),
(2623, 'BTC', '395LWh6eJiYULGp2VdH3tcRp6jtAxAAcSH', '0', '0'),
(2624, 'BTC', '3PxYNbHYifiCq6d7Pc3pAFirYZyMtJ9Lkq', '0', '0'),
(2625, 'BTC', '3KGC5z8GedaF4voLLXLoQjHXtgJRondzuZ', '0', '0'),
(2626, 'BTC', '37BEQBrvgMyvJuGKgtXY7rcQqtZBSTtgdt', '0', '0'),
(2627, 'BTC', '3CZyjUCpjyaK2M37UrvxqKZzjE75JfAMnU', '0', '0'),
(2628, 'BTC', '35kcNY2pWmvwzji6avHyvxuJ7FF9T6vXiK', '0', '0'),
(2629, 'BTC', '3CpHpV4KczrTdR4Po4VVEp3ZNPmWcxCSTV', '0', '0'),
(2630, 'BTC', '3PeYy7LBFk4bHgRifkqxGsBLmTQ8wtPvrt', '0', '0'),
(2631, 'BTC', '37B3JbdSajsEvGa31UfW25YMQvF7aAeyWb', '0', '0'),
(2632, 'BTC', '3Es6uLwPUz7Jo3mW2Jdrib2Rbpb9D8D4u8', '0', '0'),
(2633, 'BTC', '3At4J6GLPVuCTPaMH7QwoYXDnuqqHnSmV6', '0', '0'),
(2634, 'BTC', '39HUbhNbiWMag3xt8NYyhRQQ1BLZS6bZeW', '0', '0'),
(2635, 'BTC', '3KQtXcC8VMc3snDs5HG29gs3CgGS1fvWhi', '0', '0'),
(2636, 'BTC', '3JHaGKS18tGoifKHhvavs9ETrxhkTb4vgz', '0', '0'),
(2637, 'BTC', '3JAGDJsGY2dNYeFtg92JDjooXRgRExpXPq', '0', '0'),
(2638, 'BTC', '33zQ1mo2vzaejWb7aV7WfMhkguufKAL3rV', '0', '0'),
(2639, 'BTC', '3HNrTRBQJxxUmEmWPkHKxME9FhAJa3cdBV', '0', '0'),
(2640, 'BTC', '3NYgpoAUWsvYavaYKw6paHMv6hPikN5dza', '0', '0'),
(2641, 'BTC', '36NWw42h1GDxNx8HnyDS8xKs3hwFHTEJ8y', '0', '0'),
(2642, 'BTC', '3FGZqX7GPCJGNMjo7NcXhS5vJizFqCeZ9u', '0', '0'),
(2643, 'BTC', '3NupAt5f49x715GFGzq5b5MZV3AZAB7RfJ', '0', '0'),
(2644, 'BTC', '33aZAujApvWhHapybBaAWqyUEse2WrB8wM', '0', '0'),
(2645, 'BTC', '35oGGfw224oqXk5MYBADj7SgkZmeCtgECg', '0', '0'),
(2646, 'BTC', '3Fze6qhxsyGzAev1mJ6QN1YDYeJjEEdspt', '0', '0'),
(2647, 'BTC', '31qTip7hy1SAPJ1qQFLuhAN8PMUGkyvRa6', '0', '0'),
(2648, 'BTC', '3HmbtVuBsBEoy3npuRswbZMYJ7FaYouSMK', '0', '0'),
(2649, 'BTC', '3Kx7eydBBkTgXvcZFirJoh1gbya955EXA3', '0', '0'),
(2650, 'BTC', '37B1WzX6zvUEZZQdBefcEsWBi24obWRXpw', '0', '0'),
(2651, 'BTC', '33YK3yWGzXX5LBPDa56AaQvcDo61sjPhWh', '0', '0'),
(2652, 'BTC', '3F7ZeWptMaZsEjyWRnheLnx45tmYyLLmjm', '0', '0'),
(2653, 'BTC', '37DEvbmRCE3zqnsJqrbZEETZ6axgyrgYH1', '0', '0'),
(2654, 'BTC', '3LQXQpTBYYpC9zjiXrd6Ry5H6PqYvfhaDA', '0', '0'),
(2655, 'BTC', '3FCgtxhB2Z7QrGZMCEFAAqEGE31bSwBcSR', '0', '0'),
(2656, 'BTC', '3AjAz87aaNRFKkVCNh3pjh8vRaACLwzNqu', '0', '0'),
(2657, 'BTC', '3K8wZe641kfYxfRCBrfuX7ggi75us3uc5p', '0', '0'),
(2658, 'BTC', '39LYsfeKX6GwJWttMzMDKQbe6ZyjWUvZiC', '0', '0'),
(2659, 'BTC', '3FqfLR9BkEutQAhiiZbZ4dYaukfo3tnkhM', '0', '0'),
(2660, 'BTC', '3Emx2Sjw6MVLmyb7uKHENvdCps1iZLvrtz', '0', '0'),
(2661, 'BTC', '3L2ZA1qsRrT27m1G7LX43uqEBNSSp3wgJE', '0', '0'),
(2662, 'BTC', '38CrnMG1cxjJjrUWrxB93Ers8RQ39oY2bG', '0', '0'),
(2663, 'BTC', '32n517UaSAAQf9yQLgGeUdv7ReBN9EBWLv', '0', '0'),
(2664, 'BTC', '3MvJmSJP7pN9jBQHzgtX4wu5unuk6no4uQ', '0', '0'),
(2665, 'BTC', '33MAxiGdWTymNvJGRCZEEMcGBiAjviUoMh', '0', '0'),
(2666, 'BTC', '3MGwF1MhtgX4sNubzdJAcKLW1vvD8s9Rdk', '0', '0'),
(2667, 'BTC', '36vFNrwkL2u7PtQ4e67FeU3Jr8kbdfWk31', '0', '0'),
(2668, 'BTC', '3227aq4enTk5VJ9aWEkVrmoue61Pw3u6nV', '0', '0'),
(2669, 'BTC', '3FMhgh8BTyqV6tpFHU83QCTWJZRhgevQPf', '0', '0'),
(2670, 'BTC', '3FkwNhk5Fc3iounpkQHhQqsSDf6ENBPNx7', '0', '0'),
(2671, 'BTC', '32q3KXdv8KoA12P5AY9M28SAQhTVCe51cq', '0', '0'),
(2672, 'BTC', '3QT2Wg3ijt6k66kiawrKxDV1AQe6LHY5pw', '0', '0'),
(2673, 'BTC', '3GgitnXCM8fdvNvB2Vt4mkJuep5KL4LS37', '0', '0'),
(2674, 'BTC', '3Kqiar4TMFN2Vde73nbm927F6dmDJp8om1', '0', '0'),
(2675, 'BTC', '3HYYmCFdiKSwMnLz2f5KDqTXdbXuvr9HB3', '0', '0'),
(2676, 'BTC', '3EnPJvHhqYwwWHnFBjaPAM59LHwoFKLc9E', '0', '0'),
(2677, 'BTC', '3EVPL4eLkR82jbQi1UXGhmQkBgF7w9QwPu', '0', '0'),
(2678, 'BTC', '39GruBr73rkMiuxin8uncdTq4sPpQJc46A', '0', '0'),
(2679, 'BTC', '3C6YDm6oNNoLEBfZ9LYCaRynTMPSeLmZXu', '0', '0'),
(2680, 'BTC', '3E8S4eVRpSftXxc2aHMJGXhEQ8mbi8fvtH', '0', '0'),
(2681, 'BTC', '3QQ2ppHiVB3xXbfD7yqFn3Bg9WtrPPYNnL', '0', '0'),
(2682, 'BTC', '3MYg1564tWwLsmzKGHBLm2FtKvMjK3Bwwe', '0', '0'),
(2683, 'BTC', '39y432MzWEtJ4qzDbC89UQrUnN1Enm7hYc', '0', '0'),
(2684, 'BTC', '3LuQGSbh9tLuN2i8Qxh8qweAeZ7xM4EiRk', '0', '0'),
(2685, 'BTC', '33fsiiRdrRN3M2mSznbfXxwZfNA3oWeZA2', '0', '0'),
(2686, 'BTC', '3LxLxQ9G4B1sBvy19D1rSKowAp5vszk9sS', '0', '0'),
(2687, 'BTC', '37iKRumhEogcyC6kNt4UrCr5hTfTq1TNVN', '0', '0'),
(2688, 'BTC', '39jVfhbhCa19MDqWmXHdh3sJ1Sj3JGhgZd', '0', '0'),
(2689, 'BTC', '3ANS2jLVqTbHd6DehawX4gneSH89SRttV5', '0', '0'),
(2690, 'BTC', '38W1jxN4XUMEj5KPWz1jvBP9XDSjZiz8MP', '0', '0'),
(2691, 'BTC', '3FytKwCS7LZ5zYigLpXDNXnQ9iccaAAyW4', '0', '0'),
(2692, 'BTC', '3BUsToBMULNqGNrV9NpgJSS3ByVqJTXUiN', '0', '0'),
(2693, 'BTC', '38rCoLe9DynWzPFKSnze67kS1ZHf48HJuq', '0', '0'),
(2694, 'BTC', '37GwmrjVP93Ah5cntPgXJqCbUCGxx3T79K', '0', '0'),
(2695, 'BTC', '34CyrcziGtKmuBsUXCL8HpBCNFmN6U9EDe', '0', '0'),
(2696, 'BTC', '342oVdojT6FyMYWSTjZgUwP41MZY5di7u4', '0', '0'),
(2697, 'BTC', '34ZHT7C6TTmDRyZAvF6qb3kVFmDiqSwWoU', '0', '0'),
(2698, 'BTC', '37KCFFLCEcfEBiuob6Np5U3QF8fubVtAbC', '0', '0'),
(2699, 'BTC', '33uaao1975rZoUj5b7MywAAu6rPCDH5Zx3', '0', '0'),
(2700, 'BTC', '3MS8dsWeSbH4ZCnPWvPgJ8WbZ7E22sLeZ9', '0', '0'),
(2701, 'BTC', '31jGHNfVPBP9Fxjvm6oxjnR4J6C5dqqiuV', '0', '0'),
(2702, 'BTC', '335UCTsSD7nRPWPf9V1gRpqfijsSd9asma', '0', '0'),
(2703, 'BTC', '39SJzdFVzu6Sv1fqeox9W249uJgxq95qtE', '0', '0'),
(2704, 'BTC', '36woQWivoD9ryjHonQZg4Dya3WwBdGgSgW', '0', '0'),
(2705, 'BTC', '32kuDwbA23vHX8C8KEBTzzZyHa7HfciaEr', '0', '0'),
(2706, 'BTC', '3PJGx66yFMCN7aiib3o9squ9Zo8uUojqaH', '0', '0'),
(2707, 'BTC', '39NzWaFupJup8UrXsXSaPWDSdfUtkX58gT', '0', '0'),
(2708, 'BTC', '3MnyFTSXpB2hfNjs8F3aVwbpS5WbB4kpYw', '0', '0'),
(2709, 'BTC', '35oS9qHMtErdsasJrLXiCfKx2WyW1j6HAf', '0', '0'),
(2710, 'BTC', '35ZimmkuG9RjaptbN4rCQTe6YjiByy1aR4', '0', '0'),
(2711, 'BTC', '3Df9qXXHLYJF9rm2xqpgEQwcJokzCXdYdv', '0', '0'),
(2712, 'BTC', '3Lv1K8VzgE1q7b6Ch6owbnBASqABp6x6Fd', '0', '0'),
(2713, 'BTC', '3Amp1yygwX74oMDy81QbuS6BGz71LDJrDJ', '0', '0'),
(2714, 'BTC', '3EWbhJWYZVKYrubUehD6UrAPhzBbVCmibd', '0', '0'),
(2715, 'BTC', '37ab42UuTSbLbHuBcJH5DpCd6cjFbN8NyF', '0', '0'),
(2716, 'BTC', '3CXHuSHxoCfYKZNj4H7eA2ZnGBsZSQApka', '0', '0'),
(2717, 'BTC', '37EzEMrrWs1poiHVtFZzJMmt3t4Vwgmkd2', '0', '0'),
(2718, 'BTC', '3LMRvA93a5Xa2hy9C2WjMvQNMDQJdHHqbv', '0', '0'),
(2719, 'BTC', '3FV7kowV6tH2vdfoP3kXhzxmUfJKRWZRzy', '0', '0'),
(2720, 'BTC', '3AF78Ry4HJjnbh8anFmYEX7LRL3W6wnESw', '0', '0'),
(2721, 'BTC', '3PGwmGGJ1RM7RfBtkQK6SotgR6VJ7y2EBg', '0', '0'),
(2722, 'BTC', '34ssuCtgL4Ar1gji3meH6xrrw41CkoRmV9', '0', '0'),
(2723, 'BTC', '3DY5cGSRr1iNMcnCYtx3eLKretCCC7RRua', '0', '0'),
(2724, 'BTC', '3E1GH5iDzZjg6Ba9zjTciboRuyd6dU21M8', '0', '0'),
(2725, 'BTC', '32QLuGtYpvuxvzmnaop1ptbDMbKo1fVnFy', '0', '0'),
(2726, 'BTC', '3DVs32nw6ME3s9ieDLjLrQkvcGZZH6a1VE', '0', '0'),
(2727, 'BTC', '3McaaxU9gAmbeqkvZDog3HtSZXaQTK3QUY', '0', '0'),
(2728, 'BTC', '3PeDFZbMYthJBQ6HnaEQ1gSDeZD3PcMp2z', '0', '0'),
(2729, 'BTC', '3PUtMNwEBCm23pbDWzsn7mA9ekQxint64K', '0', '0'),
(2730, 'BTC', '3CmGrAdX6dSnY2NsqbsCiaVZ2ijC6Zz8Ac', '0', '0'),
(2731, 'BTC', '3PTjLWP3bNDvgVPAahRQZZtvCjSSbcfqF6', '0', '0'),
(2732, 'BTC', '32UgmBTDeKn2CTGjrLEMo9TtadtFSFAhBB', '0', '0'),
(2733, 'BTC', '3AmnzAjrDK4t5tjCNBioBUjDAHd8rNaawW', '0', '0'),
(2734, 'BTC', '37phPGvHCs5xQ25xTVjMwSeLtcFxDYzazZ', '0', '0'),
(2735, 'BTC', '3QPm9hjx86vowQ6XkFxJN3k95f1nf2fBTf', '0', '0'),
(2736, 'BTC', '3AKaFGbvoshwCdo39QZBjv1pjYeR8gSaYx', '0', '0'),
(2737, 'BTC', '32mzUknS6a5ZYnbRyqgogiHnmHA85cNEym', '0', '0'),
(2738, 'BTC', '3Ma7vutd589SUY2RuNn8dLV9avsi9hWM8z', '0', '0'),
(2739, 'BTC', '3QuGebM7BUHgau369JJ4xT5MUrd1z9eRS2', '0', '0'),
(2740, 'BTC', '36roxmpouXZtvR55Q6GFPSVEQLZ1rxtv1j', '0', '0'),
(2741, 'BTC', '3LFkNoJ728JTKGNsErBXFfp7FnaFa9TcjY', '0', '0'),
(2742, 'BTC', '3NVp86rMqsgsRLWcPCeiGZvvNurmZhqzAi', '0', '0'),
(2743, 'BTC', '3G59qujq3yKu7XJXEyCYGeVke79SuFJSsP', '0', '0'),
(2744, 'BTC', '333WEDSL1CJn5awh4gjAdJ8cjBJG8pW7Q7', '0', '0'),
(2745, 'BTC', '3LiCkNtToQ3Xx4JviocHNV4aQ9ukMgX3oT', '0', '0'),
(2746, 'BTC', '3HSnkEwobYS3hzTRVAbkakW5V9yhLaWpND', '0', '0'),
(2747, 'BTC', '3Nr97sEs59dDGYHF1c2ciovP2QvWZR5HR9', '0', '0'),
(2748, 'BTC', '335peaLFNr12NGdhzfbaoNVcFFWtPpGxWw', '0', '0'),
(2749, 'BTC', '34GVZotnJEsdhJAmabPyEC7aNWPSZvzF6m', '0', '0'),
(2750, 'BTC', '3DJcis4J5DCymAjKYDLhTRSEt1k9rMrZuN', '0', '0'),
(2751, 'BTC', '32RWWRVS7T6p7t3wE9LZibJGrRMAEdaMtS', '0', '0'),
(2752, 'BTC', '38WPiJwp6EgLVacVTTkx4x7rugrV2cVQNr', '0', '0'),
(2753, 'BTC', '3Dr7gfbd5KqBPMc7acf9EBKr1HqAAV4PFs', '0', '0'),
(2754, 'BTC', '3A88Guc6ritaV1RqDXQ3RJyvYz9DHxtPRY', '0', '0'),
(2755, 'BTC', '3H3KirTQizGduSnz1F8vEFXHKXKLDbPKxk', '0', '0'),
(2756, 'BTC', '3PphZjWddya4d1kMk11JzashsMDun3mgRV', '0', '0'),
(2757, 'BTC', '34oqS2AJehfBUxtbwfuDte8mHbv59sSJZs', '0', '0'),
(2758, 'BTC', '3QpNLk7udv5ctBynvGvAbmgHhz5MBXhh4z', '0', '0'),
(2759, 'BTC', '38oYALEZZbdHK3Wsvr7RyiCZiTSGRubs1o', '0', '0'),
(2760, 'BTC', '3B56N8ocpKocUv5YzzTX2SmkmUCu5aZrPX', '0', '0'),
(2761, 'BTC', '3BBfRkMy7T35UdZYnm7nsKSwPRabBeNbnL', '0', '0'),
(2762, 'BTC', '3BuvJR49nwehU65tLZ9jrSbD8uybcNdQZX', '0', '0'),
(2763, 'BTC', '3EcXT9Nt3AZrnqnUJaT9R75oF8C5ehoiiU', '0', '0'),
(2764, 'BTC', '38Jif5DHHFph4HMSATRPh2BYWi8ZApXiH9', '0', '0'),
(2765, 'BTC', '3AyK8PucuH4yUBcTJvwFvFEcfyEY96gWLt', '0', '0'),
(2766, 'BTC', '3MGS4XJm2Lnfk1rVk2HX3NGVi8FnhQGdZd', '0', '0'),
(2767, 'BTC', '3QvCjAXBHJSgzAKE9jJTHg3zwLmZ6j7zyo', '0', '0'),
(2768, 'BTC', '3GStqqp3SgtZ4LQVZUzsYkc5qukKcbqrMw', '0', '0'),
(2769, 'BTC', '3JWvHrratQ4CbeeQ5gHYZst2U7YWeWaxBo', '0', '0'),
(2770, 'BTC', '3GmjUQKf27TsGGD44PLAxXqkHfkPbnsFzg', '0', '0'),
(2771, 'BTC', '37BoND8zvLvnNS2rz5PKnSC9xresYLKuXM', '0', '0'),
(2772, 'BTC', '37x5aCrBcRHiZqWByYcKpbY4a2eKfRKbBZ', '0', '0'),
(2773, 'BTC', '3N7QMZtrEUra3hT2ERV6AkkXuJinT23kbx', '0', '0'),
(2774, 'BTC', '3KT2oiGcpGzz3ksWFHQAGFiZaMyGW3n2PD', '0', '0'),
(2775, 'BTC', '36nsMGuwds2KJmxChMop6Rv4jeKS2nFvKR', '0', '0'),
(2776, 'BTC', '3PVnbe1TNz78qPGH6iVDG7XvCgucsvobFT', '0', '0'),
(2777, 'BTC', '338q73oNHgoKrWp1rfJuTfmpufZ1zjkbLU', '0', '0'),
(2778, 'BTC', '3PX3jUfqBSChpbX4JUb2ef4SjMmnBsCE5H', '0', '0'),
(2779, 'BTC', '3BmAEuJS2gRoY5xK1nPpRUUq8qHuWSJUtr', '0', '0'),
(2780, 'BTC', '35bmWrcuoCnvccokrCKLwvZZJh7sswwA1s', '0', '0'),
(2781, 'BTC', '33LGJn7MgS7hUiHgfCKYraDXFG4wjwkFJv', '0', '0'),
(2782, 'BTC', '3LWPicjvE7FLpanVs3iJ1pSy1HTaSiHygM', '0', '0'),
(2783, 'BTC', '3H2J52vuSVHFAnhWHAePkqEyDAuspMetqt', '0', '0'),
(2784, 'BTC', '32UbeGSmVJC9cPNvGsxidQ2ziApai8Jn92', '0', '0'),
(2785, 'BTC', '3GFXHLxAPVRtqUXhno9hy9jYvY988PBm4Q', '0', '0'),
(2786, 'BTC', '3J6nrC7Z6cRsr24q36H6qX4767ps9amqSq', '0', '0'),
(2787, 'BTC', '3JiLZz7wxNneT6jsogBnEkespT7CAYjXiZ', '0', '0'),
(2788, 'BTC', '32m3kdeWs1RndTq4Hq1EQjvhqznLeFv3pm', '0', '0'),
(2789, 'BTC', '3HUdiogmLYVNGegHx51GsPbfP6SWUXCmhF', '0', '0'),
(2790, 'BTC', '3KZFNBdqX3dYU57V5sVHVHgp9Z58yp93dz', '0', '0'),
(2791, 'BTC', '37eVHdnUeNG4DGCQBgp3MrczH9cwTYmxed', '0', '0'),
(2792, 'BTC', '38SuiyKiGkNAbnqWKj8YRMzoWFCZVGpAcM', '0', '0'),
(2793, 'BTC', '3Coaty6RZ44ZkieafhLx4zLU6ZzFRPd6Bf', '0', '0'),
(2794, 'BTC', '3FbiQxVGtaAEceaqraz6AexrDyRMhbRUWy', '0', '0'),
(2795, 'BTC', '3QdmJV9hPMD8b34bgWzRYzqyxR6syEWGAW', '0', '0'),
(2796, 'BTC', '32JhV1VP4PqENDpM4YCfpCMARxsLDAXDpp', '0', '0'),
(2797, 'BTC', '3LJ5oyniT7vSfSYKtjmtwpLiRwoVjVWcTJ', '0', '0'),
(2798, 'BTC', '3PR49LHVFVNn5ytM4rXtKVn1X7G8dJPAbT', '0', '0'),
(2799, 'BTC', '3HJ8rHWZwHZiHxZc4cKuyX7yrYpAKmoaJj', '0', '0'),
(2800, 'BTC', '3BuMV6CnDxf6k9uWAiM73Jzo1PZ9Z3iGM4', '0', '0'),
(2801, 'BTC', '3KWtshpAk5R8aLt5yh1JNsPMhyPbKZAut4', '0', '0'),
(2802, 'BTC', '37grn7uMTWZNvznF91H9Jtcs2EunHbSTcf', '0', '0'),
(2803, 'BTC', '3NrJLmoAotqDxsQ9UEiz3M1vMJ1GxekEDY', '0', '0'),
(2804, 'BTC', '39PPKyhqnANhfzJbP5T761TY9KChVPMxSB', '0', '0'),
(2805, 'BTC', '3MAM5Htxk3R6vdJJ8wFhi5E8niZJ7j4XtP', '0', '0'),
(2806, 'BTC', '38XFv9zeM6fNV2eeR5XmTmojbmeuxcEnym', '0', '0'),
(2807, 'BTC', '3NfEvMQcnm6akAbsZqfKENR9pkN7pjQ4i2', '0', '0'),
(2808, 'BTC', '3NxncSGiZfg55ZvCAKo6KQLS4yGnd2Ggsm', '0', '0'),
(2809, 'BTC', '3GcZ5zLug7oafcBQ1WqT6a4geuEKTynJkP', '0', '0'),
(2810, 'BTC', '3J4L9dd69Aa6H52p47dkfbykFZiNwGU6p8', '0', '0'),
(2811, 'BTC', '3CQYg179GV34p5ihHp9SaYSoYbap4Espac', '0', '0'),
(2812, 'BTC', '3759MEpZQjbCNBzWErR5ZVCVFrrjNq7QAC', '0', '0'),
(2813, 'BTC', '39FGR8saUMkKPusy2dm2STfut28W9d9dFG', '0', '0'),
(2814, 'BTC', '3QJ5n5EDiQNhP1M1ctPtEUgcBqZZYB7oe1', '0', '0'),
(2815, 'BTC', '3PbWagp2c6MSsPj13x7XDfdkDZ89m8DyrT', '0', '0'),
(2816, 'BTC', '3KLEhgLMo4xmc85FTyYppm3ZZVXBrT7goE', '1', '0'),
(2817, 'BTC', '37t3D5LMLx5WajKhpTeME21HmaKk5ABVem', '1', '0'),
(2818, 'BTC', '3A1sJeemyiEaMW5pH9SgWjDTmyEEJ54nW5', '1', '0'),
(2819, 'BTC', '3BKEFM8FvH2tgqPE6edZsKjPdEd27UT3cB', '1', '0'),
(2820, 'BTC', '34DQBYhYYWFhnfn9ufajmGPfjsuY97aLZN', '1', '0'),
(2821, 'BTC', '3LjvVZWkmLZZM7b1ArrhQADETFXoGBeXBc', '1', '0'),
(2822, 'BTC', '3D5zrtQEs87Eag2WbepCsxzQbxqo322oNh', '1', '0'),
(2823, 'BTC', '3KPwD535d6PtdWDTMRaKUvwLF1CMd31dxo', '1', '0'),
(2824, 'BTC', '39Y4dgAftrxyxDB3NVqC6N9euRbevnxx2v', '1', '0'),
(2825, 'BTC', '39KJJiHSZMvmJQmB6x6raoKeQQ9cNAmvtB', '1', '0'),
(2826, 'BTC', '3GGptjHKC9qtEptHqZxwgwgqcfy5k7UN3v', '0', '0'),
(2827, 'BTC', '3B1ycH9TQnifojqkE4Vxqfju8w4VCtbUBv', '0', '0'),
(2828, 'BTC', '396i41Xwx7YDLyESyZ4c1xpfpWX7ig7Xop', '0', '0'),
(2829, 'BTC', '3PPCTHbZYqnYSvE9FRfjRKw9JjWzXLKejJ', '0', '0'),
(2830, 'BTC', '38Zfpb1TZd8QhQLYnKHeCkAqc1wZnD8hGC', '0', '0'),
(2831, 'BTC', '3JPpLB6z5CPiJMP5LmGKKobD7gKmoWFuBh', '0', '0'),
(2832, 'BTC', '3MciiZHdE6h3CPWHjGQrgzuVAGXbcdz8P4', '0', '0'),
(2833, 'BTC', '395LWh6eJiYULGp2VdH3tcRp6jtAxAAcSH', '0', '0'),
(2834, 'BTC', '3PxYNbHYifiCq6d7Pc3pAFirYZyMtJ9Lkq', '0', '0'),
(2835, 'BTC', '3KGC5z8GedaF4voLLXLoQjHXtgJRondzuZ', '0', '0'),
(2836, 'BTC', '37BEQBrvgMyvJuGKgtXY7rcQqtZBSTtgdt', '0', '0'),
(2837, 'BTC', '3CZyjUCpjyaK2M37UrvxqKZzjE75JfAMnU', '0', '0'),
(2838, 'BTC', '35kcNY2pWmvwzji6avHyvxuJ7FF9T6vXiK', '0', '0'),
(2839, 'BTC', '3CpHpV4KczrTdR4Po4VVEp3ZNPmWcxCSTV', '0', '0'),
(2840, 'BTC', '3PeYy7LBFk4bHgRifkqxGsBLmTQ8wtPvrt', '0', '0'),
(2841, 'BTC', '37B3JbdSajsEvGa31UfW25YMQvF7aAeyWb', '0', '0'),
(2842, 'BTC', '3Es6uLwPUz7Jo3mW2Jdrib2Rbpb9D8D4u8', '0', '0'),
(2843, 'BTC', '3At4J6GLPVuCTPaMH7QwoYXDnuqqHnSmV6', '0', '0'),
(2844, 'BTC', '39HUbhNbiWMag3xt8NYyhRQQ1BLZS6bZeW', '0', '0'),
(2845, 'BTC', '3KQtXcC8VMc3snDs5HG29gs3CgGS1fvWhi', '0', '0'),
(2846, 'BTC', '3JHaGKS18tGoifKHhvavs9ETrxhkTb4vgz', '0', '0'),
(2847, 'BTC', '3JAGDJsGY2dNYeFtg92JDjooXRgRExpXPq', '0', '0'),
(2848, 'BTC', '33zQ1mo2vzaejWb7aV7WfMhkguufKAL3rV', '0', '0'),
(2849, 'BTC', '3HNrTRBQJxxUmEmWPkHKxME9FhAJa3cdBV', '0', '0'),
(2850, 'BTC', '3NYgpoAUWsvYavaYKw6paHMv6hPikN5dza', '0', '0'),
(2851, 'BTC', '36NWw42h1GDxNx8HnyDS8xKs3hwFHTEJ8y', '0', '0'),
(2852, 'BTC', '3FGZqX7GPCJGNMjo7NcXhS5vJizFqCeZ9u', '0', '0'),
(2853, 'BTC', '3NupAt5f49x715GFGzq5b5MZV3AZAB7RfJ', '0', '0'),
(2854, 'BTC', '33aZAujApvWhHapybBaAWqyUEse2WrB8wM', '0', '0'),
(2855, 'BTC', '35oGGfw224oqXk5MYBADj7SgkZmeCtgECg', '0', '0'),
(2856, 'BTC', '3Fze6qhxsyGzAev1mJ6QN1YDYeJjEEdspt', '0', '0'),
(2857, 'BTC', '31qTip7hy1SAPJ1qQFLuhAN8PMUGkyvRa6', '0', '0'),
(2858, 'BTC', '3HmbtVuBsBEoy3npuRswbZMYJ7FaYouSMK', '0', '0'),
(2859, 'BTC', '3Kx7eydBBkTgXvcZFirJoh1gbya955EXA3', '0', '0'),
(2860, 'BTC', '37B1WzX6zvUEZZQdBefcEsWBi24obWRXpw', '0', '0'),
(2861, 'BTC', '33YK3yWGzXX5LBPDa56AaQvcDo61sjPhWh', '0', '0'),
(2862, 'BTC', '3F7ZeWptMaZsEjyWRnheLnx45tmYyLLmjm', '0', '0'),
(2863, 'BTC', '37DEvbmRCE3zqnsJqrbZEETZ6axgyrgYH1', '0', '0'),
(2864, 'BTC', '3LQXQpTBYYpC9zjiXrd6Ry5H6PqYvfhaDA', '0', '0'),
(2865, 'BTC', '3FCgtxhB2Z7QrGZMCEFAAqEGE31bSwBcSR', '0', '0'),
(2866, 'BTC', '3AjAz87aaNRFKkVCNh3pjh8vRaACLwzNqu', '0', '0'),
(2867, 'BTC', '3K8wZe641kfYxfRCBrfuX7ggi75us3uc5p', '0', '0'),
(2868, 'BTC', '39LYsfeKX6GwJWttMzMDKQbe6ZyjWUvZiC', '0', '0'),
(2869, 'BTC', '3FqfLR9BkEutQAhiiZbZ4dYaukfo3tnkhM', '0', '0'),
(2870, 'BTC', '3Emx2Sjw6MVLmyb7uKHENvdCps1iZLvrtz', '0', '0'),
(2871, 'BTC', '3L2ZA1qsRrT27m1G7LX43uqEBNSSp3wgJE', '0', '0'),
(2872, 'BTC', '38CrnMG1cxjJjrUWrxB93Ers8RQ39oY2bG', '0', '0'),
(2873, 'BTC', '32n517UaSAAQf9yQLgGeUdv7ReBN9EBWLv', '0', '0'),
(2874, 'BTC', '3MvJmSJP7pN9jBQHzgtX4wu5unuk6no4uQ', '0', '0'),
(2875, 'BTC', '33MAxiGdWTymNvJGRCZEEMcGBiAjviUoMh', '0', '0'),
(2876, 'BTC', '3MGwF1MhtgX4sNubzdJAcKLW1vvD8s9Rdk', '0', '0'),
(2877, 'BTC', '36vFNrwkL2u7PtQ4e67FeU3Jr8kbdfWk31', '0', '0'),
(2878, 'BTC', '3227aq4enTk5VJ9aWEkVrmoue61Pw3u6nV', '0', '0'),
(2879, 'BTC', '3FMhgh8BTyqV6tpFHU83QCTWJZRhgevQPf', '0', '0'),
(2880, 'BTC', '3FkwNhk5Fc3iounpkQHhQqsSDf6ENBPNx7', '0', '0'),
(2881, 'BTC', '32q3KXdv8KoA12P5AY9M28SAQhTVCe51cq', '0', '0'),
(2882, 'BTC', '3QT2Wg3ijt6k66kiawrKxDV1AQe6LHY5pw', '0', '0'),
(2883, 'BTC', '3GgitnXCM8fdvNvB2Vt4mkJuep5KL4LS37', '0', '0'),
(2884, 'BTC', '3Kqiar4TMFN2Vde73nbm927F6dmDJp8om1', '0', '0'),
(2885, 'BTC', '3HYYmCFdiKSwMnLz2f5KDqTXdbXuvr9HB3', '0', '0'),
(2886, 'BTC', '3EnPJvHhqYwwWHnFBjaPAM59LHwoFKLc9E', '0', '0'),
(2887, 'BTC', '3EVPL4eLkR82jbQi1UXGhmQkBgF7w9QwPu', '0', '0'),
(2888, 'BTC', '39GruBr73rkMiuxin8uncdTq4sPpQJc46A', '0', '0'),
(2889, 'BTC', '3C6YDm6oNNoLEBfZ9LYCaRynTMPSeLmZXu', '0', '0'),
(2890, 'BTC', '3E8S4eVRpSftXxc2aHMJGXhEQ8mbi8fvtH', '0', '0'),
(2891, 'BTC', '3QQ2ppHiVB3xXbfD7yqFn3Bg9WtrPPYNnL', '0', '0'),
(2892, 'BTC', '3MYg1564tWwLsmzKGHBLm2FtKvMjK3Bwwe', '0', '0'),
(2893, 'BTC', '39y432MzWEtJ4qzDbC89UQrUnN1Enm7hYc', '0', '0'),
(2894, 'BTC', '3LuQGSbh9tLuN2i8Qxh8qweAeZ7xM4EiRk', '0', '0'),
(2895, 'BTC', '33fsiiRdrRN3M2mSznbfXxwZfNA3oWeZA2', '0', '0'),
(2896, 'BTC', '3LxLxQ9G4B1sBvy19D1rSKowAp5vszk9sS', '0', '0'),
(2897, 'BTC', '37iKRumhEogcyC6kNt4UrCr5hTfTq1TNVN', '0', '0'),
(2898, 'BTC', '39jVfhbhCa19MDqWmXHdh3sJ1Sj3JGhgZd', '0', '0'),
(2899, 'BTC', '3ANS2jLVqTbHd6DehawX4gneSH89SRttV5', '0', '0'),
(2900, 'BTC', '38W1jxN4XUMEj5KPWz1jvBP9XDSjZiz8MP', '0', '0'),
(2901, 'BTC', '3FytKwCS7LZ5zYigLpXDNXnQ9iccaAAyW4', '0', '0'),
(2902, 'BTC', '3BUsToBMULNqGNrV9NpgJSS3ByVqJTXUiN', '0', '0'),
(2903, 'BTC', '38rCoLe9DynWzPFKSnze67kS1ZHf48HJuq', '0', '0'),
(2904, 'BTC', '37GwmrjVP93Ah5cntPgXJqCbUCGxx3T79K', '0', '0'),
(2905, 'BTC', '34CyrcziGtKmuBsUXCL8HpBCNFmN6U9EDe', '0', '0'),
(2906, 'BTC', '342oVdojT6FyMYWSTjZgUwP41MZY5di7u4', '0', '0'),
(2907, 'BTC', '34ZHT7C6TTmDRyZAvF6qb3kVFmDiqSwWoU', '0', '0'),
(2908, 'BTC', '37KCFFLCEcfEBiuob6Np5U3QF8fubVtAbC', '0', '0'),
(2909, 'BTC', '33uaao1975rZoUj5b7MywAAu6rPCDH5Zx3', '0', '0'),
(2910, 'BTC', '3MS8dsWeSbH4ZCnPWvPgJ8WbZ7E22sLeZ9', '0', '0'),
(2911, 'BTC', '31jGHNfVPBP9Fxjvm6oxjnR4J6C5dqqiuV', '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gt_captchas`
--
ALTER TABLE `gt_captchas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gt_captchas_id_uindex` (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `domains`
--
ALTER TABLE `domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=774;

--
-- AUTO_INCREMENT for table `gt_captchas`
--
ALTER TABLE `gt_captchas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219274;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20608;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2912;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
